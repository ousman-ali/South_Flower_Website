export const headers = {
  "Content-Type": "application/json",
  Accept: "application/json",
};
