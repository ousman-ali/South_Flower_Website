module.exports=[30135,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_South_Flower__next-internal_server_app_about_page_actions_8371aaa9.js.map