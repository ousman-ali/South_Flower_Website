module.exports=[37066,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_South_Flower__next-internal_server_app__not-found_page_actions_cd5ec97b.js.map