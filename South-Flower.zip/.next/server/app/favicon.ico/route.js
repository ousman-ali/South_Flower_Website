var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__cee0a606._.js")
R.c("server/chunks/3d860_South_Flower__next-internal_server_app_favicon_ico_route_actions_b3506aed.js")
R.m(70985)
module.exports=R.m(70985).exports
