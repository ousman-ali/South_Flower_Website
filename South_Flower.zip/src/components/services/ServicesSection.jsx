"use client";

import { motion, useAnimationFrame } from "framer-motion";
import { Sparkles, ShieldCheck, Stars, Globe2 } from "lucide-react";
import Link from "next/link";
import { useRef } from "react";

// Floating shape component with continuous animation
const FloatingShape = ({ delay = 0, className = "", style }) => {
  const ref = useRef(null);

  useAnimationFrame((t) => {
    if (!ref.current) return;
    const rotate = (t / 50 + delay * 100) % 360;
    const y = Math.sin(t / 1000 + delay) * 30;
    const x = Math.cos(t / 1500 + delay) * 20;
    ref.current.style.transform = `translate(${x}px, ${y}px) rotate(${rotate}deg)`;
  });

  return <div ref={ref} className={className} style={style} />;
};

export default function ServicesSection({ servicesData }) {
  function getFAIcon(iconName) {
    if (
      typeof iconName === "string" &&
      iconName.trim() !== "" &&
      (iconName.startsWith("fa ") || // "fa fa-facebook"
        iconName.startsWith("fa-") || // "fa-facebook"
        iconName.startsWith("fas ") || // "fas fa-user"
        iconName.startsWith("fas-") || // "fas-user"
        iconName.startsWith("fab ") || // "fab fa-instagram"
        iconName.startsWith("fab-") || // "fab-instagram"
        iconName.startsWith("far ") || // regular icons
        iconName.startsWith("far-"))
    ) {
      // VALID → return the icon directly
      return <i className={`${iconName} text-xl`}></i>;
    }

    // INVALID → fallback icon
    return <i className="fa-solid fa-concierge-bell  text-xl"></i>;
  }

  return (
    <section className="relative py-10 overflow-hidden bg-gradient-to-b from-black/95 via-black/90 to-black/95">
      {/* Animated Background Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_80%_50%_at_50%_50%,#000_70%,transparent_110%)]" />

      {/* Large Floating Shapes - External Background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Gradient Orbs */}
        <FloatingShape
          delay={0}
          className="absolute top-20 left-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl"
        />
        <FloatingShape
          delay={2}
          className="absolute bottom-20 right-10 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl"
        />
        <FloatingShape
          delay={4}
          className="absolute top-1/2 left-1/3 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl"
        />

        {/* Geometric Shapes */}
        <FloatingShape
          delay={1}
          className="absolute top-32 right-32 w-40 h-40 border-2 border-blue-500/20 rounded-3xl"
        />
        <FloatingShape
          delay={3}
          className="absolute bottom-40 left-40 w-32 h-32 border-2 border-purple-500/20"
          style={{ clipPath: "polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)" }}
        />
        <FloatingShape
          delay={5}
          className="absolute top-1/3 right-1/4 w-36 h-36 border-2 border-emerald-500/20 rounded-full"
        />
        <FloatingShape
          delay={2.5}
          className="absolute bottom-1/3 left-1/4 w-28 h-28 bg-gradient-to-br from-orange-500/10 to-amber-500/10"
          style={{
            clipPath: "polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)",
          }}
        />
        <FloatingShape
          delay={4.5}
          className="absolute top-1/4 left-1/2 w-24 h-24 border-2 border-cyan-500/20 rotate-45"
        />
        <FloatingShape
          delay={6}
          className="absolute bottom-1/4 right-1/3 w-44 h-44 border-2 border-pink-500/20 rounded-2xl rotate-12"
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header with animation */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-10"
        >
          {/* Badge */}
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-block mb-6 px-4 py-2 rounded-full bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20 backdrop-blur-sm"
          >
            <span className="text-sm font-semibold bg-gradient-to-r text-blue-400">
              Advanced Transport Manufacturing
            </span>
          </motion.div>

          <h2 className="text-5xl md:text-6xl font-bold mb-6 text-gray-300">
            Our <span className=" text-blue-400 ">Featured Solutions</span>
          </h2>

          <p className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed text-justify">
            We provide durable, high-performance fabrication services including
            fuel cargo tankers, dry cargo bodies, high bed semi-trailers,
            drawbar trailers, and custom steel structures engineered to meet
            industry standards
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {servicesData.slice(0, 4).map((service, index) => (
            <motion.div
              key={index}
              initial={{ y: 60, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{
                duration: 0.6,
                delay: index * 0.15,
                ease: [0.22, 1, 0.36, 1],
              }}
              whileHover={{ y: -12, transition: { duration: 0.3 } }}
              className="group relative"
            >
              {/* External Floating Shapes around card */}
              <motion.div
                className={`absolute -top-8 -right-8 w-24 h-24 bg-blue-500/20 rounded-full blur-2xl opacity-0 group-hover:opacity-100`}
                animate={{
                  scale: [1, 1.3, 1],
                  rotate: [0, 180, 0],
                }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />

              <motion.div
                className="absolute -bottom-8 -left-8 w-20 h-20 border-2 border-current opacity-10 group-hover:opacity-30"
                style={{
                  borderColor: "#3b82f6",
                }}
                animate={{
                  rotate: [0, 360],
                  scale: [1, 1.2, 1],
                }}
                transition={{
                  duration: 10,
                  repeat: Infinity,
                  ease: "linear",
                }}
              />

              {/* Gradient glow on hover */}
              <div
                className={`absolute -inset-1 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-2xl opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-500`}
              />

              {/* Main Card with glass effect */}
              <div className="relative bg-black/40 backdrop-blur-xl rounded-2xl p-8 border border-white/10 hover:border-white/20 transition-all duration-500 shadow-2xl group-hover:shadow-[0_0_40px_rgba(59,130,246,0.3)] h-full flex flex-col">
                {/* Animated gradient border on top */}
                <div
                  className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-t-2xl`}
                >
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent"
                    animate={{
                      x: ["-200%", "200%"],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "linear",
                      repeatDelay: 1,
                    }}
                  />
                </div>

                {/* Internal animated shapes */}
                <motion.div
                  className="absolute top-4 right-4 w-20 h-20 opacity-5"
                  animate={{
                    rotate: [0, 360],
                  }}
                  transition={{
                    duration: 20,
                    repeat: Infinity,
                    ease: "linear",
                  }}
                >
                  <div
                    className={`w-full h-full bg-gradient-to-br from-blue-500 to-cyan-400`}
                    style={{
                      clipPath: "polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)",
                    }}
                  />
                </motion.div>

                <motion.div
                  className="absolute bottom-4 left-4 w-16 h-16 border-2 border-current opacity-5 rounded-full"
                  animate={{
                    scale: [1, 1.4, 1],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                />

                {/* Icon with gradient background */}
                <div className="relative mb-6 flex justify-center">
                  <motion.div
                    className={`relative p-4 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-2xl shadow-lg`}
                    whileHover={{
                      rotate: [0, -10, 10, -10, 0],
                      scale: 1.1,
                    }}
                    transition={{ duration: 0.5 }}
                  >
                    <div
                      className={`absolute inset-0 text-blue-500 rounded-2xl blur-xl opacity-50 group-hover:opacity-100 transition-opacity duration-300`}
                    />
                    <div className="relative text-white">
                      {getFAIcon(service.icon_class)}
                    </div>
                  </motion.div>
                </div>

                {/* Content */}
                <Link href={`/service/${service.slug}`}>
                  <h3 className="relative text-xl font-bold text-white mb-3 group-hover:bg-gradient-to-r group-hover:bg-clip-text hover:text-blue-400 transition-all duration-300">
                    {service.title.length > 40
                      ? service.title.slice(0, 40) + " ..."
                      : service.title}
                  </h3>
                </Link>

                <p className="relative text-gray-400 leading-relaxed flex-grow text-justify">
                  {service.short_description.length > 60
                    ? service.short_description.slice(0, 60) + " ..."
                    : service.short_description}
                </p>

                {/* Hover indicator */}
                <motion.div
                  className={`mt-6 h-1 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left`}
                />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="text-center mt-12"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="group relative px-8 py-4 bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-semibold rounded-xl overflow-hidden shadow-lg hover:shadow-[0_0_40px_rgba(59,130,246,0.5)] transition-all duration-300 cursor-pointer"
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-blue-600 to-cyan-600"
              initial={{ x: "100%" }}
              whileHover={{ x: 0 }}
              transition={{ duration: 0.3 }}
            />
            <Link
              href="/service"
              className="relative z-10 flex items-center gap-2"
            >
              Explore All Services
              <motion.span
                animate={{ x: [0, 5, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                →
              </motion.span>
            </Link>
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}
