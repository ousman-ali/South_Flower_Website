module.exports=[45675,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_South_Flower__next-internal_server_app_getquote_page_actions_0b426e91.js.map