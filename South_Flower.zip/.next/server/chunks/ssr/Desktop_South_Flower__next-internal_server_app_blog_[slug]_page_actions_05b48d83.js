module.exports=[2970,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_South_Flower__next-internal_server_app_blog_%5Bslug%5D_page_actions_05b48d83.js.map