module.exports=[24632,a=>{a.v("/_next/static/media/favicon.34054f99.ico")},48445,a=>{"use strict";let b={src:a.i(24632).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=Desktop_South_Flower_src_app_f5be49ac._.js.map