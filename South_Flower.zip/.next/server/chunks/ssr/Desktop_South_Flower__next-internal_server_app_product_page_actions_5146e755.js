module.exports=[17166,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_South_Flower__next-internal_server_app_product_page_actions_5146e755.js.map