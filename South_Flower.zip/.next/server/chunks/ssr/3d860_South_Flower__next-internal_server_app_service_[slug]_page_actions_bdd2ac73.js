module.exports=[20684,(a,b,c)=>{}];

//# sourceMappingURL=3d860_South_Flower__next-internal_server_app_service_%5Bslug%5D_page_actions_bdd2ac73.js.map