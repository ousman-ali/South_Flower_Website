module.exports=[76896,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_South_Flower__next-internal_server_app_service_page_actions_8c05e6af.js.map