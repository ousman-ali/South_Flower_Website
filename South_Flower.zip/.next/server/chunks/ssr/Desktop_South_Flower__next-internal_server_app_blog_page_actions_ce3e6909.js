module.exports=[29850,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_South_Flower__next-internal_server_app_blog_page_actions_ce3e6909.js.map