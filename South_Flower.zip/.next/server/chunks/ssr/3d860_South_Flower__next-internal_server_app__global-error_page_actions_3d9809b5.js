module.exports=[24675,(a,b,c)=>{}];

//# sourceMappingURL=3d860_South_Flower__next-internal_server_app__global-error_page_actions_3d9809b5.js.map