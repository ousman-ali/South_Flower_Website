module.exports=[39598,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_South_Flower__next-internal_server_app_contact_page_actions_c7750e18.js.map