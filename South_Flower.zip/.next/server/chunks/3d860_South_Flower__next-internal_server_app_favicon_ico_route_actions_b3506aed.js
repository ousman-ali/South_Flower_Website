module.exports=[86723,(e,o,d)=>{}];

//# sourceMappingURL=3d860_South_Flower__next-internal_server_app_favicon_ico_route_actions_b3506aed.js.map